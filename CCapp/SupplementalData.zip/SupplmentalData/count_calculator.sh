#!/bin/bash

# A script to count reads from interval file
# input is bam file,interval file and output file
# Ex:   sh count_calculator.sh test.bam mm10_1kb_intervals.tab counts.tab 

export bamfile=$1
export i1=$2

export o1=$3



module load bedtools
module load BEDOPS
module load samtools


samtools view   -f 0x2 -q 10 -b $bamfile|bedtools bamtobed -i -|awk ' { print $1,$2,$3 } ' | sort-bed -|tr ' ' '\t' > temp.bed

if [[ -s temp.bed ]] ; then
echo "process has failed.please rerun" 
else
echo "process seems to be finished " 
fi ;


bedmap --echo --fraction-map 1 --count $i1 temp.bed|tr '|' '\t'| awk ' { print $1,$2,$3,$4}' > $o1

echo "count file is generated"
