
#script to create custom bins from reference genome
#input:Reference fasta file,binsize,outputfile
#example : bin_creator.py mm10.fa 2000 2kn_bins.tab


#!/usr/bin/python
from sys import argv
from Bio import SeqIO
import re

script,fastafile,bin,outputfile=argv

output_file = open(outputfile,'w')

n=int(bin)
fasta_sequences = SeqIO.parse(open(fastafile),'fasta')
for fasta in fasta_sequences:
    name, sequence = fasta.id, fasta.seq.tostring()
    for i in range(0, len(sequence), n):
        if i+n< len(sequence):
           seq=sequence[i:i+n]
           if i==0: 
               print >>output_file,"%s:%s-%s"%(name,i,i+n)
           else:
               print >>output_file,"%s:%s-%s"%(name,i,i+n)
        else:
              seq=sequence[i:len(sequence)]
              print >>output_file,"%s:%s-%s"%(name,i,len(sequence))


