######################################################
# CNv analysis of 1k bin count data from
#   WGS of 69 CC Strain genomes
# This script defines private deletions
# GAC - December 14, 2016
# revised w/ new data Feb 10, 2017
#   note the mix of data.table, data.frame and data_table
#        has made this a paintful script to write!
###########################
library(data.table)
library(tidyverse)

# setwd("~/GARY/Projects/CC_WGS_69Strains")

######################################################
# Set up for analysis of binned read counts
######################################################

####
#read the 1Kb bin-level count data
Count <- fread("Data/BinCountData_Feb2017/CC_69_samples-1kb_Counts.bed",sep="\t",header=TRUE)
StrainNames <- names(Count)

# pull out the chr and position information
BinStats <- select(Count, chr, start, stop)
BinStats <- mutate(BinStats, chr = factor(Count$chr, levels=c("chr1","chr2","chr3",
                        "chr4","chr5","chr6","chr7","chr8","chr9","chr10",
                        "chr11","chr12","chr13","chr14","chr15","chr16",
                        "chr17","chr18","chr19","chrM","chrX","chrY")) )

# create an autosomes indicator
BinStats <- transform(BinStats, Autosome = !(chr %in% c("chrM","chrX","chrY")))
# table(BinStats$Autosome)
#   2,405,755 Autosome Bins

# create an X Chr indicator
BinStats <- transform(BinStats, ChrX=(chr=="chrX"))
# table(BinStats$ChrX)
#   168,032 Chr X bins

# remove annotation columns from Counts table
Count <- select(Count, -chr, -start, -stop)
Count <- as.matrix(Count,ncol=69)
names(Count) <- StrainNames
# dim(Count)
# 2665549 bins     69 strains

# ####
# # Create strain summary data
# #Strain IDs
# StrainData <- data_frame(StrainName = names(Count))
#
# #median, total counts by strains = column stats
# StrainData <- transform(StrainData, Median = apply(Count,2,median),
#                                     Total = colSums(Count) )
#
# # range of total counts per strain
# range(StrainData$Total)/(10^6)
# # 300M to 1091M
#
# # range of median coverage
# range(StrainData$Median)


######################################################
# Apply Column Normalization
#  CPM = counts per 1G
######################################################

CPM <- tbl_df(apply(Count, 2, function(x){(x/sum(x))*10^9}))
names(CPM) <- names(Count)
#
# apply(CPM,2,median)
# # medians are all around 375

######################################################
# Bin Level Summary Stats
######################################################

####
# compute the bin level summary stats
BinStats <- transform(BinStats,
                TotalCPM = rowSums(CPM),
                TotalCount = rowSums(Count),
                # SdCPM = apply(CPM,1,sd),
                # MadCPM = apply(CPM,1,mad),
                MinCPM = Biobase::rowQ(as.matrix(CPM),1),
                MinCount = Biobase::rowQ(as.matrix(Count),1),
                MedianCPM = Biobase::rowMedians(as.matrix(CPM)),
                MedianCount = Biobase::rowMedians(as.matrix(Count)),
                MaxCPM = Biobase::rowQ(as.matrix(CPM),69),
                CPM_2 = Biobase::rowQ(as.matrix(CPM),2) #,
                # CPM_3 = Biobase::rowQ(as.matrix(CPM),3),
                # CPM_4 = Biobase::rowQ(as.matrix(CPM),4)
                )

# #####
# #total counts
# range(BinStats$TotalCount)     # range is 0 to 77M
# #
# sum(BinStats$TotalCount==0)    # 17599 rows have all zero counts
# #
# sum(BinStats$TotalCount > 10^6) # 126 rows have sums greater than 1M
# sum(BinStats$TotalCount > 30000) # 16676 rows have sums greater than 10,000

# #######
# # column-normalized counts
# # the distribution of Bin Counts is strikingly bimodal due to Autosome/X
# quartz()
# ggplot(BinStats, aes(x=TotalCPM)) + geom_histogram(bins=200) +
#   scale_x_log10(limits=c(5000,50000))
#
# #####
# #autosomal median - find center of bin count range
# quartz()
# ggplot(subset(BinStats,Autosome), aes(x=MedianCPM)) +
#   geom_histogram(bins=200) + xlim(200,600)
# sum(subset(BinStats,Autosome)$MedianCPM<300)/sum(BinStats$Autosome)
# sum(subset(BinStats,Autosome)$MedianCPM>500)/sum(BinStats$Autosome)
# median(subset(BinStats,Autosome)$MedianCPM)
#
# #x chr median - find center of bin count range
# quartz()
# ggplot(subset(BinStats,ChrX), aes(x=MedianCPM)) +
#   geom_histogram(bins=200) + xlim(100,400)
# median(subset(BinStats,ChrX)$MedianCPM)
# median(subset(BinStats,ChrX)$SdCPM)
# sum(subset(BinStats,ChrX)$MedianCPM<150)/sum(BinStats$ChrX)
# sum(subset(BinStats,ChrX)$MedianCPM>250)/sum(BinStats$ChrX)

########
# "Use1" to mark binss with well behaved median CPM
########
BinStats <- transform(BinStats,
                      Use1 = ( (Autosome & (MedianCPM>=300 & MedianCPM<=500) |
                              (ChrX & (MedianCPM>=150 & MedianCPM<=250)) ) ) )

# ####
# # look at the Max in the "Use1" bins
# quartz()
# ggplot(subset(BinStats, Autosome&Use1)) +
#  geom_histogram(aes(x=MaxCPM),bins=100) + xlim(200,1000)
#
# # Max/Median
# quartz()
# ggplot(subset(BinStats, Autosome&Use1)) +
#  geom_histogram(aes(x=MaxCPM/MedianCPM),bins=100) + xlim(1,3)
# #
# with(BinStats, sum(Autosome & Use1 & (MaxCPM/MedianCPM)>2)/sum(Autosome & Use1 ) )
# #
# quartz()
# ggplot(subset(BinStats, ChrX&Use1)) +
#  geom_histogram(aes(x=MaxCPM/MedianCPM),bins=100) + xlim(1,3)
# #
# with(BinStats, sum(ChrX & Use1 & (MaxCPM/MedianCPM)>2)/sum(ChrX & Use1 ) )

########
# "Use2" to mark binss with well behaved median CPM
########
BinStats <- transform(BinStats,
                      Use2 = ( Use1 & ((MaxCPM/MedianCPM)<2) ) )
# with(BinStats, table(Use1, Use2))

# #######
# # Median/CPM_2
# quartz()
# ggplot(subset(BinStats, Autosome&Use2)) +
#  geom_histogram(aes(x=MedianCPM/CPM_2),bins=100) + xlim(1,3)
# #
# with(BinStats, sum(Autosome & Use2 & (MedianCPM/CPM_2)>1.5)/sum(Autosome & Use2 ) )
# #
# quartz()
# ggplot(subset(BinStats, ChrX&Use1)) +
#  geom_histogram(aes(x=MedianCPM/CPM_2),bins=100) + xlim(1,3)
# #
# with(BinStats, sum(ChrX & Use2 & (MedianCPM/CPM_2)>1.75)/sum(ChrX & Use2 ) )

########
# "Use3" to mark bins where the second smallest count is within range of median
########
BinStats <- transform(BinStats,
                      Use3 = (ChrX & Use2 & (MedianCPM/CPM_2)<1.75) |
                        (Autosome & Use2 & (MedianCPM/CPM_2)<1.5) )
# with(BinStats, table(Use1, Use3))

# ########
# #Min Count
# quartz()
# ggplot(subset(BinStats, Autosome&Use3)) +
#  geom_histogram(aes(x=MinCount),binwidth=1, center=0) + xlim(0,100)
# #
# with(BinStats, sum(Autosome & Use2 & (MinCount<13) ) )
# with(BinStats, sum(Autosome & Use3 & (MinCount<13) ) )
#
# quartz()
# ggplot(subset(BinStats, Use3&ChrX)) +
#  geom_histogram(aes(x=MinCount),binwidth=1, center=0) + xlim(0,50)
# #
# with(BinStats, sum(ChrX & Use2 & (MinCount<7) ) )
# with(BinStats, sum(ChrX & Use3 & (MinCount<7) ) )

########
# "Use4" bins that look like private deletions
########
BinStats <- transform(BinStats,
                      Use4 = (ChrX & Use3 & (MinCount<7)) |
                        (Autosome & Use3 & (MinCount<13)) )
#
# with(BinStats, sum(Autosome & Use4) )
# with(BinStats, sum(ChrX & Use4) )

########################
# Look for clusters bins with private deletion signature

# use filter to count hits in a window around target
# note that this introduces NA at start and end of each chr
my.filter <- function(x){
  as.numeric(stats::filter(x, rep(1,9)))
}
BinStats <- transform(BinStats, Filter1 = my.filter(Use4))
# BinStats <- transform(BinStats, Filter2 = my.filter(Use2))
# with(BinStats, table(Filter1, Filter2))
# #
# with(BinStats, sum(Use4 & Window>1))
# with(BinStats, sum(Use4 & Window>2))
# with(BinStats, sum(Use4 & Window>3))
# with(BinStats, sum(Use4 & Window>4))
# with(BinStats, sum(Use4 & Window>5))
# with(BinStats, sum(Use4 & Window>6))
# with(BinStats, sum(Use4 & Window>7))
# with(BinStats, sum(Use4 & Window>8))

########
# Use5 selects bins with neighbors that are also deletions
####
BinStats <- transform(BinStats, Use5 = (Use4 & (Filter1>3)))

###
# assign strain with min count
name.min <- function(x){
  names(Count)[which.min(x)]
}
#
BinStats <- transform(BinStats, MinStrain=apply(Count,1,name.min))

#grab all the rows that pass Use5
Deletion.All <- select(subset(BinStats,Use5),chr,start,stop,MinStrain,MinCount,MedianCount)

#collapse repeated row of same deletion
Deletions <- transform(Deletion.All, Mb=round(start/10^6)) %>%
group_by(MinStrain, chr, Mb) %>%
  summarise(Begin=first(start),End=last(stop)) %>%
  ungroup() %>% data.frame()

# write to file
write.csv(Deletions,"DeletionList_V7.csv")

####
# plot
pdf("DeletionPlots_v7.pdf")
for(i in 1:dim(Deletions)[1]){

  # get count data in region surrounding deletion
  #i <- 1
  Offset <- 50000
  row.indx <- which(BinStats$chr==Deletions[i,"chr"] &
                  BinStats$start >= Deletions[i,"Begin"]-Offset &
                  BinStats$stop <= Deletions[i,"End"]+Offset)
  col.indx <- as.integer(Deletions[i,"MinStrain"])
  StrainCount <- Count[row.indx, col.indx]

  tmp <- data.frame(cbind(BinStats[row.indx,],StrainCount))

  #plot
  print(
    #quartz()
    ggplot(tmp, aes(x=(start+stop)/2, y=StrainCount/MedianCount, color=Use2)) +
      geom_point() + ylim(0,2) +
      ggtitle(paste(Deletions[i,"MinStrain"],as.character(Deletions[i,"chr"]),sep=" "))
  )
}
dev.off()



















