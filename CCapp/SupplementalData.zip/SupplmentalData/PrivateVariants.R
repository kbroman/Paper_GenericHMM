#######################################################################
#  CC Strain WGS project
#  Analysis of private variants
#  GAC Dec 22, 2016
#
#  revised March 12 v3
#     final pass on updated list of private variants
#     with errors corrected from DB query
#  revised March 8
#     uses an updated private variants file that filters out variants that
#     that occur on a unique haplotype (across 69 strains)
#  revised: March 2 2016
#    analysis of updated variant data files for paper resubmission
#   Anuj extracted new privaye variants from DB using filters
#   there is a new CpG flag in the data and no need for formatting
#
#  revised: Jan 3, 2016
#    new version of private variants Private_Variants_V3.csv
#      recvd from Anuj includes X CHR haplotypes
#    these data can be extracted from the SQLite DB using query ...
#    replaced variable name spaces with "_"
#    X chr genotypes converted from "A" to "AA" etc. to simplify code, I hope.
#    removed "chr" prefix from CHRosome names
#    changed "." to "NA" in ID column
#
#######################################################################
#
library(data.table)
library(tidyverse)
library(stringr)

# setwd("~/GARY/Projects/CC_WGS_69Strains")

#############################
# Define CC.colors - note use of ALT color for AA
CC.colors <- c(AA="#DAA520",DD="#1010F0",BB="#404040",CC="#F08080",
  HH="#9000E0",GG="#F00000",EE="#00A0F0",FF="#00A000")
# AA="#F0F000"

#######################################################################
#  1. LOAD DATA
#    data = private variants from DB query
#    StrainData = summary data on strains includes generations of breeding
#    Genotype = diplotype calls in 1kb bins
#
#    Clean up data
#    Output high impact variants
#
#######################################################################

###########################
# load private variant data

####
data <- read_csv("Data/Private_Variants.csv")
dim(data)
# 27800    36

####
#name patch
# names(data)
names(data)[35] <- "STRAIN"

####
# remove Y and M variants in this analysis
# table(data$CHROM)
# # there are 999 variants on Y and 1 on M
# sum(is.na(data$CHROM))
# # there are no missing values
#
# filter out Y and M
data <- filter(data, CHROM %in% str_c("chr",c(as.character(1:19),"X")) )
dim(data)
# there are 26800 private variant calls on automsomes and X

####
# reorder Chromosomes as factor and tabulate variants by CHR
data <- transform(data, CHR=factor(CHROM, levels=str_c("chr",c(as.character(1:19),"X"))))
table(data$CHR)
#
# variant counts by Chr
#  chr1  chr2  chr3  chr4  chr5  chr6  chr7  chr8  chr9 chr10 chr11 chr12 chr13 chr14 chr15 chr16
#  1899  1747  1723  1549  1443  1588  1395  1251  1234  1446  1278  1113  1107  1161  1123  1026
# chr17 chr18 chr19  chrX
#   970   844   617  2286

####
#create Autosome
data <- transform(data, Autosome=(CHR %in% str_c("chr",c(as.character(1:19)))))
table(data$Autosome)
# there are 24514 autosomal private variants
# and 2286 X chr private variants

####
# convert key indicators to logical
data <- mutate(data, SNP=(SNP==1),
                     INDEL=(INDEL==1),
                     CPG=(CPG==1))
with(data, table(SNP))   #14917 SNPs
with(data, table(INDEL)) #11883 INDEL
with(data, table(CPG))   #1343 of SNPs are at CpG sites

###
# create indicator for novel snps = no record in DBSNP
data <- mutate(data, NOVEL=ifelse(str_sub(ID,1,2)=="rs",FALSE,TRUE))

# table variant type by novelty
with(data, table(NOVEL,SNP))
#        SNP
# NOVEL       0     1
#   FALSE  2822  1310
#   TRUE   9061 13607

####
# clean up the haplotypes

# tabulate variant Haplotypes
# with(data, table(HAP))
# there are no het or missing diplotypes

#create a Haplotype variable with X chr haplotypes converted to diplotype code
# this is just convenient
data <- mutate(data,
           Haplotype = factor(ifelse(CHR %in% c("chrX"),str_c(HAP,HAP),HAP)))
# # check
with(data, table(Haplotype))
#
# variant count by haplotypes show excess variants on FF and GG haplotypes
# Haplotype
#   AA   BB   CC   DD   EE   FF   GG   HH
# 2429 2565 2716 2698 2780 5701 4920 2991
# mean(c(2429, 2565, 2716, 2698, 2780, 2991)) # = 2696.5
# (5701+4920)-2*2696.5 = 5228 rough estimate of excess variants
#
with(data, table(SNP, Haplotype))
#    Haplotype
# SNP   AA   BB   CC   DD   EE   FF   GG   HH
#   0  714  533  775  762  837 3814 3297 1151
#   1 1715 2032 1941 1936 1943 1887 1623 1840
# most of the excess is indels, snps are under-represented here
# this crude analysis assume haplotype frequencies are balanced - they are not.

# tabulate autosomal variants by haplotype
with(filter(data, Autosome), table(Haplotype))
# Haplotype
#    AA    BB    CC    DD    EE    FF    GG    HH
#  2207  2258  2361  2386  2584  5305  4593  2820

# tabulate chrX variants by haplotype
with(filter(data, CHR=="chrX"), table(Haplotype))
# Haplotype
#   AA   BB   CC   DD   EE   FF   GG   HH
#  222  307  355  312  196  490 3135  171
#
# excess of FF and GG variants applies to Autosomes and X,
#  the GG excess is especially high on X

###########################
# high impact variants
write.csv(subset(data, (SNP==1 | INDEL==1)&(HIGH_SNPEFF_IMPACT == 1))[,c(35,36,3,8:16)],
          "HighImpactVars.csv")
# we need to assign these to genes
# check that nearby frameshifts are not self-correcting

###########################
# load strain data
# to get breeding generation of the sequenced animal

StrainData <- read_csv("Data/CCStrains.csv") %>%
  select(Strain, N_Founders, Seq_Generation, Standard_Coverage, Mitochondria, ChrY) %>%
  mutate(Strain=str_split(Strain,"/",simplify=TRUE)[,1]) %>%
  mutate(Strain=factor(Strain)) %>%
  rename(Gen=Seq_Generation, Cov=Standard_Coverage, ChrM=Mitochondria)

# excess of "A" and depletion of "F" and "G"
with(StrainData, table(ChrM))

# depletion of "F" and "G"
with(StrainData, table(ChrY))

# generation of sequenced mouse ranges from 17 to 37
with(StrainData, table(Gen))

###########################
# load genotypes - diplotype across all genomes in 1kb blocks

# we will use this below to define haplotype blocks
Genotype <- fread("Data/CC_69_samples-1kb_haplo.bed",sep="\t",header=TRUE)

# remove Y and mito
Genotype <- subset(Genotype, !(chr=="chrM" | chr=="chrY"))

#transform chr to factor
str(Genotype)
Genotype <- rename(Genotype, CHR=chr, Start=start, End=stop)
Genotype <- transform(Genotype, CHR = factor(CHR,
                                  levels=c("chr1","chr2","chr3",
                                           "chr4","chr5","chr6","chr7","chr8","chr9","chr10",
                                           "chr11","chr12","chr13","chr14","chr15","chr16",
                                           "chr17","chr18","chr19","chrX") ) )
table(Genotype$CHR)

#######################################################################
# 2. Create the main data structure for analysis - HomBlock
#    break the genome into blocks of homozygous genotype
#    on each Chr of each Strain with SNP and Indel counts
#######################################################################

#####
# this function finds the start, end and haplotype of
# runs of adjacent bins with same genotype
# x is a character vector of genotypes from one strain & one Chr
findruns <- function(x){
  runs <- rle(x)
  index <- c(1, cumsum(runs$lengths))
  homoz <- which(runs$values %in% c("AA","BB","CC","DD","EE","FF","GG","HH",
                                    "A","B","C","D","E","F","G","H"))
  Blocks <- data_frame(start = Genotype[index[homoz],]$Start,
                       end = Genotype[index[homoz+1]-1,]$End,
                       hap = runs$values[homoz])
  Blocks
}

####
# apply the findruns() function to create the Homozygosity Blocks dataframe HomBlock
# may take a few minutes
HomBlock <- NULL
for(chr in str_c("chr",c(as.character(1:19),"X")) ){
    tmp <- apply(subset(Genotype, CHR==chr),2,findruns)
    tmp <- plyr::ldply(tmp)
    tmp <- transform(tmp, Chr=chr)
    HomBlock <- bind_rows(HomBlock,tmp)
}
names(HomBlock) <- c("Strain","Start","End","Hap","Chr")
# ignore warning about factor levels

####
# patch Haplotype labels - convert X chr to diplotype notation
oldvals <- c("AA","BB","CC","DD","EE","FF","GG","HH",
             "A","B","C","D","E","F","G","H")
newvals <- c("AA","BB","CC","DD","EE","FF","GG","HH",
             "AA","BB","CC","DD","EE","FF","GG","HH")
HomBlock <- transform(HomBlock, Hap = factor(newvals[match(Hap, oldvals)]))
table(HomBlock$Hap)
#
#   AA   BB   CC   DD   EE   FF   GG   HH
# 1050 1116 1102 1120 1151  702  654 1107
# the depletion of CAST and PWK is clear in the block counts

####
# convert char variables to factor
HomBlock <- transform(HomBlock,
          Chr=factor(Chr, levels=str_c("chr",c(as.character(1:19),"X") )),
          Strain=factor(Strain))
table(HomBlock$Chr)
table(HomBlock$Strain) %>% mean()
# there are about 116 blocks per strain
table(HomBlock$Strain) %>% sd()
# plus or minus 13

####
#create an autosome factor
HomBlock <- transform(HomBlock,
            Autosome=factor(as.numeric(Chr=="chrX")+1,labels=c("A","X")))
table(HomBlock$Autosome)

#create an wild-strain factor
HomBlock <- transform(HomBlock,
            Wild=factor(as.numeric(Hap=="FF"|Hap=="GG")+1,labels=c("Dom","Wild")))
table(HomBlock$Wild)
# 1356/(6646+1356) = 17% of block are "wild" compared to 25% expectation

# number of blocks by strain and Chr
with(HomBlock, table(Strain, Chr))

####
#count SNPs and Indels - slow looping
HomBlock <- mutate(HomBlock, SNP=0, Indel=0)
for(i in 1:dim(HomBlock)[1]){
  HomBlock$SNP[i] <- sum(subset(data,
                            STRAIN==HomBlock$Strain[i] &
                              as.character(CHR)==as.character(HomBlock$Chr[i]) &
                              POS>=HomBlock$Start[i] & POS<=HomBlock$End[i])$SNP)
  HomBlock$Indel[i] <- sum(subset(data,
                            STRAIN==HomBlock$Strain[i] &
                              as.character(CHR)==as.character(HomBlock$Chr[i]) &
                              POS>=HomBlock$Start[i] & POS<=HomBlock$End[i])$INDEL)
}
#
# range(HomBlock$SNP)  # 0-54
# range(HomBlock$Indel)  # 0-74

####
# create a block size variable in Mb
HomBlock <- mutate(HomBlock, Size=(End-Start)/10^6)
#
quartz()
ggplot(HomBlock, aes(x=Size)) + geom_histogram(bins=100)
# distn of homozygous block sizes

####
# convert counts to rates per Mb
HomBlock <- transform(HomBlock, SNPRate=SNP/Size,
                      IndelRate=Indel/Size)
# range(HomBlock$SNPRate)
# range(HomBlock$IndelRate)

#####
# remove the small blocks

#how many small blocks of size < 1 Mb?
with(HomBlock, sum(Size<1))
# 986
# how much of genome is covered by small blocks?
sum(subset(HomBlock, Size<1)$Size)/(sum(as.numeric(HomBlock$Size)))
#0.00102
# blocks of Size<1Mb make up a very small fraction of total

# with(filter(HomBlock,Size<0.5), sum(SNP))
with(filter(HomBlock,Size<1), sum(SNP))
# we loose 5 or 11 SNPs

# with(filter(HomBlock,Size<0.5), sum(Indel))
with(filter(HomBlock,Size<1), sum(Indel))
# loose 8 or 23 Indels

# remove small haplotype blocks
dim(HomBlock)  # 8002
HomBlock <- filter(HomBlock, Size>=1)
dim(HomBlock)  #7016
# we lost ~1000 small haplotype blocks.

####
# look at it
head(HomBlock)
#
#   Strain     Start       End Hap  Chr Autosome Wild SNP Indel   Size    SNPRate  IndelRate
# 1  CC001   3000000  32743000  BB chr1        A  Dom   1     0 29.743 0.03362136 0.00000000
# 2  CC001  62592000 137633000  EE chr1        A  Dom   3     1 75.041 0.03997815 0.01332605
# 3  CC001 138375000 153431000  HH chr1        A  Dom   5     1 15.056 0.33209352 0.06641870
# 4  CC001 153432000 163310000  CC chr1        A  Dom   0     0  9.878 0.00000000 0.00000000
# 5  CC001 167789000 180454000  HH chr1        A  Dom   2     1 12.665 0.15791552 0.07895776
# 6  CC001 180838000 195471000  AA chr1        A  Dom   0     1 14.633 0.00000000 0.06833869


#######################################################################
# 3. look at summary tables of variants by Chr, Hap, etc
#######################################################################

############################
# summary by chromosome
ChrData <- HomBlock %>%
  group_by(Chr) %>%
  summarise(SNPCount=sum(SNP),
            IndelCount=sum(Indel),
            # Length=(max(End)-min(Start))/10^6) %>%
            Length=(sum(Size))) %>%
  mutate(SNPRate=(SNPCount/Length),
         IndelRate=(IndelCount/Length))
# note: rates per Mb of homozygous diplotype

write.csv(ChrData, "Counts_Chromosome.csv")

#################################
# summary by Strain
StrainData <- left_join(StrainData,
                        left_join(
                          # autosomes
                          HomBlock %>% filter(Autosome == "A") %>%
                            group_by(Strain) %>%
                            summarise(SNP_A=sum(SNP),Indel_A=sum(Indel)),
                          # X chr
                          HomBlock %>% filter(Autosome=="X") %>%
                            group_by(Strain) %>%
                            summarise(SNP_X=sum(SNP),Indel_X=sum(Indel)) )  )

write.csv(StrainData, "Counts_Strain.csv")

###
# plot SNP v Indel counts by strains for Autosomes and X
quartz()
ggplot(StrainData,aes(x=SNP_A, y=Indel_A)) +
  geom_text(aes(label=str_sub(Strain,4,5))) +
  ggtitle("Autosomal SNP v Indel by Strain") +
  geom_smooth(method="lm")
#
quartz()
ggplot(StrainData,aes(x=SNP_X, y=Indel_X)) +
  geom_text(aes(label=str_sub(Strain,4,5))) +
  ggtitle("ChrX SNP v Indel by Strain") +
  geom_smooth(method="lm")

####
# quick look at trend by generations - Autosomal SNPs
quartz()
ggplot(StrainData,aes(x=Gen, y=SNP_A)) +
  geom_text(aes(label=str_sub(Strain,4,5))) +
  ggtitle("Autosomal SNP per Generation") +
  geom_smooth(method="lm")
#
summary(lm(SNP_A ~ Gen, data=StrainData))
# Coefficients:
#             Estimate Std. Error t value Pr(>|t|)
# (Intercept)   51.861     27.792   1.866   0.0664 .
# Gen            5.884      1.135   5.183 2.18e-06 ***
# Strains started out with 52 +/- 28 private autosome SNPs
# and they gain ~6 new autosomal SNPs per generation
# this is a simple analysis but it seems to hit the mark
#

# trend by generation - Autosomal Indels
quartz()
ggplot(StrainData,aes(x=Gen, y=Indel_A)) +
  geom_text(aes(label=str_sub(Strain,3,4))) +
  ggtitle("Autosomal Indel per Generation") +
  geom_smooth(method="lm")
#
summary(lm(Indel_A ~ Gen, data=StrainData))
# Coefficients:
#             Estimate Std. Error t value Pr(>|t|)
# (Intercept) 150.7419    53.3942   2.823  0.00625 **
# Gen           0.4298     2.1812   0.197  0.84438
# Indels do not seem to be increasing with generation
#  what can it mean?  Perhaps Indels are dominated by calling errors?

####
# does coverage affect Autosomal SNPs? no
quartz()
ggplot(StrainData,aes(x=Cov, y=SNP_A)) +
  geom_text(aes(label=str_sub(Strain,4,5))) +
  ggtitle("Autosomal SNP by Coverage") +
  geom_smooth(method="lm")
#
summary(lm(SNP_A ~ Gen+Cov, data=StrainData))

# Indels? yes
quartz()
ggplot(StrainData,aes(x=Cov, y=Indel_A)) +
  geom_text(aes(label=str_sub(Strain,4,5))) +
  ggtitle("Autosomal Indel by Coverage") +
  geom_smooth(method="lm")
# CC0039 is an outlier with low coverage and high indel rate
#
summary(lm(Indel_A ~ Cov+Gen, data=StrainData))
# Coefficients:
#             Estimate Std. Error t value Pr(>|t|)
# (Intercept)   40.690     49.459   0.823    0.414
# Gen           -1.489      1.871  -0.796    0.429
# Cov            3.331      0.624   5.339 1.24e-06 ***
#  average depth of coverage per strain has a significant effect on indel rates!
#  even after accounting for coverage effect, there is no Generation trend

#################################
# count variants by Haplotype
HapData <- HomBlock %>%
  group_by(Hap) %>%
  summarise(SNPCount=sum(SNP),
            IndelCount=sum(Indel),
            Length=(sum(Size))) %>%
  mutate(SNPRate=(SNPCount/Length),
         IndelRate=(IndelCount/Length))
# rates per Mb

HapData
#
#      Hap SNPCount IndelCount   Length    SNPRate  IndelRate
#   <fctr>    <dbl>      <dbl>    <dbl>      <dbl>      <dbl>
# 1     AA     1713        713 21483.99 0.07973380 0.03318751
# 2     BB     2029        532 25322.04 0.08012781 0.02100936
# 3     CC     1939        775 25335.06 0.07653426 0.03059002
# 4     DD     1935        759 24489.99 0.07901187 0.03099225
# 5     EE     1943        833 25387.20 0.07653464 0.03281182
# 6     FF     1887       3809 14069.48 0.13412010 0.27072786
# 7     GG     1621       3290 12343.19 0.13132743 0.26654365
# 8     HH     1839       1149 23450.09 0.07842187 0.04899768
# CAST and PWK haplotypes appear to have an excess of indels
# write_csv(VarHap, "VariantsHaplotype.csv")

####
# ratio of Indels to SNPs by Haplotype
round(with(HapData, IndelCount/SNPCount),3)
#
#  0.416 0.262 0.400 0.392 0.429 2.019 2.030 0.625
#
# The indel:snp ratio in B6 is 0.26 and increases to 0.4 for the classical strains
# and to 0.72 for WSB.  It make a huge leap to over 2.0 for CAST and PWK.
# this suggests that we are disproportionately overcounting Indels on these haplotypes.

#################################
# count variants by Haplotype & Chromosome
HapChrData <- HomBlock %>%
  group_by(Chr, Hap) %>%
  summarise(SNPCount=sum(SNP),
            IndelCount=sum(Indel),
            Length=(sum(Size))) %>%
  mutate(SNPRate=(SNPCount/Length),
         IndelRate=(IndelCount/Length))
# rates per Mb

# SNP v Indel Counts by Chr & Haplotype
quartz()
ggplot(HapChrData, aes(x=SNPCount, y=IndelCount, colour=Hap)) +
     # geom_point() +
     geom_text(aes(label=Chr)) +
     geom_smooth(method="lm",se=FALSE) +
     scale_x_log10() + scale_y_log10() +
     scale_colour_manual(values=CC.colors) +
     ggtitle("SNP v Indel Counts by Chr and Haplotype") +
     xlab("SNPS") + ylab("Indels")

# SNP v Indel Rates by Chr & Haplotype
quartz()
# pdf("SNPIndel_Rates.pdf")
ggplot(HapChrData, aes(x=log10(SNPRate*10^3), y=log10(IndelRate*10^3), colour=Hap)) +
     # geom_point() +
     geom_text(aes(label=Chr)) +
     geom_smooth(method="lm",se=FALSE) +
     # scale_x_log10() + scale_y_log10() +
     scale_colour_manual(values=CC.colors) +
     # ggtitle("SNP v Indel Rate (per Gb) by Chr and Haplotype") +
     theme_bw() +
     xlab("log10 SNPS") + ylab("log10 Indels")
# dev.off()
#  this is figure X

#################################
# count variants by Haplotype & Strain
HapStrData <- HomBlock %>%
  group_by(Strain, Hap) %>%
  summarise(SNPCount=sum(SNP),
            IndelCount=sum(Indel),
            Length=(sum(Size))) %>%
  mutate(SNPRate=(SNPCount/Length),
         IndelRate=(IndelCount/Length))
# rates per Mb

# SNP v Indel Counts by Strain & Haplotype
quartz()
ggplot(HapStrData, aes(x=SNPCount, y=IndelCount, colour=Hap)) +
     # geom_point() +
     geom_text(aes(label=str_sub(Strain,4,5))) +
     geom_smooth(method="lm",se=FALSE) +
     scale_x_log10() + scale_y_log10() +
     scale_colour_manual(values=CC.colors) +
     ggtitle("SNP v Indel Counts by Hap and Strain") +
     xlab("SNPS") + ylab("Indels")

# SNP v Indel rates by Strain & Haplotype
quartz()
ggplot(HapStrData, aes(x=SNPRate, y=IndelRate, colour=Hap)) +
     # geom_point() +
     geom_text(aes(label=str_sub(Strain,4,5))) +
     geom_smooth(method="lm",se=FALSE) +
     scale_x_log10() + scale_y_log10() +
     scale_colour_manual(values=CC.colors) +
     ggtitle("SNP v Indel Rates by Hap and Strain") +
     xlab("SNPS") + ylab("Indels")

############
# number of block of each haplotype by strain
with(HomBlock, table(Strain, Hap))
# here we see the strains that ae missing entire haplotypes

#############
#add strain generation and coverage to HomBlock
HomBlock <- left_join(HomBlock, select(StrainData,Strain,Gen,Cov))

# write.csv(HomBlock, "MutationRates.csv")

#######################################################################
# 4. Poisson regression modeling of SNP and Indel Rates
#######################################################################
#
# ##################
# # here we show that Autsome and Wild are the two important for predicting Rates
# # # we can eliminate 41 blocks with very highest rates
#
# ###
# # model fitting
#
# summary(glm(SNP ~ 1, family=poisson, offset=log(Size), data=HomBlock))
# # AIC 23428
#
# summary(glm(SNP ~ -1+Hap, family=poisson, offset=log(Size), data=HomBlock))
# # Coefficients:
# #       Estimate Std. Error z value Pr(>|z|)
# # HapAA -2.52906    0.02416 -104.67   <2e-16 ***
# # HapBB -2.52413    0.02220 -113.70   <2e-16 ***
# # HapCC -2.57002    0.02271 -113.17   <2e-16 ***
# # HapDD -2.53816    0.02273 -111.65   <2e-16 ***
# # HapEE -2.57001    0.02269 -113.28   <2e-16 ***
# # HapFF -2.00902    0.02302  -87.27   <2e-16 ***
# # HapGG -2.03006    0.02484  -81.73   <2e-16 ***
# # HapHH -2.54565    0.02332 -109.17   <2e-16 ***
# #  FF and GG SNP rates higher than the rest
# # AIC: 22761
#
# summary(glm(SNP ~ Hap+Strain, family=poisson, offset=log(Size), data=HomBlock))
# # Coefficients:
# #              Estimate Std. Error z value Pr(>|z|)
# # (Intercept) -2.630801   0.075061 -35.049  < 2e-16 ***
# # HapBB        0.003777   0.033128   0.114 0.909222
# # HapCC       -0.033660   0.033600  -1.002 0.316440
# # HapDD       -0.018767   0.033695  -0.557 0.577562
# # HapEE       -0.056181   0.033623  -1.671 0.094744 .
# # HapFF        0.509862   0.034043  14.977  < 2e-16 ***
# # HapGG        0.464564   0.035339  13.146  < 2e-16 ***
# # HapHH       -0.040564   0.034150  -1.188 0.234900
# # after accounting for strain, the FF and GG are still higher
# # AIC: 22090 - strain improves fit = strain to strain heterogenity
#
# summary(glm(SNP ~ Hap+Cov, family=poisson, offset=log(Size), data=HomBlock))
# # AIC: 22728
# summary(glm(SNP ~ Hap+Cov+Strain, family=poisson, offset=log(Size), data=HomBlock))
# # AIC: 22090 = coverage does not explain the strain-to-strain effects
#
# summary(glm(SNP ~ Wild+Autosome+Strain, family=poisson, offset=log(Size), data=HomBlock))
# # Coefficients:
# #              Estimate Std. Error z value Pr(>|z|)
# # (Intercept) -2.698187   0.072005 -37.472  < 2e-16 ***
# # WildWild     0.533378   0.019805  26.932  < 2e-16 ***
# # AutosomeX    0.510326   0.026963  18.927  < 2e-16 ***
# # AIC: 21773
#
# # try substituting generation for strain
# summary(glm(SNP ~ Wild+Autosome+Gen, family=poisson, offset=log(Size), data=HomBlock))
# # Coefficients:
# #              Estimate Std. Error z value Pr(>|z|)
# # (Intercept) -3.333806   0.046154  -72.23   <2e-16 ***
# # WildWild     0.565155   0.019372   29.17   <2e-16 ***
# # AutosomeX    0.511829   0.026951   18.99   <2e-16 ***
# # Gen          0.030187   0.001816   16.62   <2e-16 ***
# # AIC: 22181
# #  the increased AIC suggests that Gen does not capture all of the strain-heterogenity
# #  but Gen is highly significant - still to interpret the coeffs in terms of new SNPs per Mb
# # note that the meaning of intercept is changed - generation 0
#
# summary(glm(SNP ~ Wild+Autosome+Gen+Gen:Autosome, family=poisson, offset=log(Size), data=HomBlock))
# # AutosomeX:Gen  0.011714   0.005820   2.013   0.0441 *
# # marginally significant difference in rate of accumulation per Gen between Autsomes and X
#
# summary(glm(SNP ~ Wild+Autosome+Gen+Gen:Wild, family=poisson, offset=log(Size), data=HomBlock))
# # WildWild:Gen -0.019648   0.004444  -4.421  9.8e-06 ***
# # rate of accumulation is different for Wild haplotypes?
#
# ####
# # look at Indels
#
# summary(glm(Indel ~ Hap+Autosome+Strain, family=poisson, offset=log(Size), data=HomBlock))
# #              Estimate Std. Error z value Pr(>|z|)
# # (Intercept) -3.602874   0.092640 -38.891  < 2e-16 ***
# # HapBB       -0.444334   0.057528  -7.724 1.13e-14 ***
# # HapCC       -0.071808   0.052328  -1.372 0.169979
# # HapDD       -0.068355   0.052636  -1.299 0.194068
# # HapEE       -0.006516   0.051435  -0.127 0.899195
# # HapFF        2.061283   0.041648  49.492  < 2e-16 ***
# # HapGG        2.024816   0.042186  47.997  < 2e-16 ***
# # HapHH        0.399754   0.048211   8.292  < 2e-16 ***
# # AutosomeX    0.186997   0.038365   4.874 1.09e-06 ***
# #   AIC: 18480
#
# summary(glm(Indel ~ Hap+Autosome+Gen, family=poisson, offset=log(Size), data=HomBlock))
# #              Estimate Std. Error z value Pr(>|z|)
# # (Intercept) -3.768658   0.064590 -58.348  < 2e-16 ***
# # HapBB       -0.460171   0.057280  -8.034 9.46e-16 ***
# # HapCC       -0.083509   0.051900  -1.609    0.108
# # HapDD       -0.072408   0.052143  -1.389    0.165
# # HapEE       -0.008535   0.051004  -0.167    0.867
# # HapFF        2.117804   0.040840  51.856  < 2e-16 ***
# # HapGG        2.094668   0.041301  50.718  < 2e-16 ***
# # HapHH        0.394834   0.047633   8.289  < 2e-16 ***
# # AutosomeX    0.181102   0.038003   4.765 1.88e-06 ***
# # Gen          0.014356   0.002127   6.750 1.48e-11 ***
# # AIC: 19716
# # Again, AIC suggest that there is more strain heterogeneity than explained by Gen,
# # but Gen is highly significant - this is different from "simple analysis above
# # suggests that we do well to account for other factors before estimating rate of increase

############
# fit Poisson regression models for SNP and Indel
# use these to get Strain-specific rates adjusted for Autsome/ChrX, Dom/Wild and coverage

# center coverage at 30x
HomBlock <- mutate(HomBlock, Cov=Cov-30)

#SNPs
fit.SNP <- glm(SNP ~ -1+Strain+Autosome+Wild+Cov, family=poisson, offset=log(Size), data=HomBlock)
StrainData <- mutate(StrainData, SNPCoef = coef(fit.SNP)[1:69])


#Indels
fit.Indel <- glm(Indel ~ -1+Strain+Autosome+Wild+Cov, family=poisson, offset=log(Size), data=HomBlock)
StrainData <- mutate(StrainData, IndelCoef = coef(fit.Indel)[1:69])

##########
#  use generation number to predict rates

quartz()
ggplot(StrainData, aes(x=Gen, y=exp(SNPCoef))) +
  geom_text(aes(label=substr(Strain,4,5)),size=5) +
  ylab("SNPs per Mb") + xlab("Generation") +
  geom_smooth(method="lm") + theme_bw()
#
summary(lm(exp(SNPCoef) ~ Gen, data=StrainData))
# Coefficients:
#              Estimate Std. Error t value Pr(>|t|)
# (Intercept) 0.0171277  0.0097527   1.756   0.0836 .
# Gen         0.0023928  0.0003984   6.006 8.66e-08 ***
  #  slope = 2.4 SNPs per Gb per Generation - allowing for non-zero intercept
# 17 errors per Gb?

summary(lm(exp(SNPCoef) ~ Gen-1, data=StrainData))
#  slope = 3.1 SNPs per Gb per Generation -forcing zero intercept


quartz()
ggplot(StrainData, aes(x=Gen, y=exp(IndelCoef))) +
  geom_text(aes(label=substr(Strain,4,5)),size=5) +
  ylab("Indels per Mb") + xlab("Generation") +
  geom_smooth(method="lm") + theme_bw()
#
summary(lm(exp(IndelCoef) ~ Gen, data=StrainData))
# Coefficients:
#              Estimate Std. Error t value Pr(>|t|)
# (Intercept) 0.0210392  0.0077727   2.707  0.00861 **
# Gen         0.0004789  0.0003175   1.508  0.13620
# 0.48 indels per Gb per generation
# 21.1 errors per Gb

summary(lm(exp(IndelCoef) ~ Gen-1, data=StrainData))
# 1.3 indels per generation
#  the non-zero intercept may be telling us how many errors there are
#  so we should use the rate estimates with intercept terms

#######################################################################
# 5. look at the patterns of nucleotide substitutions
#######################################################################

# table of substitution counts
with(subset(data,SNP==1),table(REF,ALT))

# table of substitution rates
round(with(subset(data,SNP==1),table(REF,ALT)/sum(SNP==1)),3)

# are patterns different for NOVEL SNPs?
round(with(filter(data,SNP==1 & NOVEL),table(REF,ALT)/sum(SNP==1 & NOVEL)),3)
round(with(filter(data,SNP==1 & !NOVEL),table(REF,ALT)/sum(SNP==1 & !NOVEL)),3)
# slightly higher rate of CT in non-NOVEL SNPs - possible heteroplasmy

#####
# Novel variants have no previous record in DBSNP - no rs#
table(data$NOVEL)
# there are 22686 variants with no rsid#
# and 4139 variants seen before
#   22686/(4139+22686) --. 84.6% of the variants have never been seen before

with(data, table(NOVEL, HAP))
#        HAP
# NOVEL     AA   BB   CC   DD  EE   FF   GG   HH
#   FALSE  339  261  387  312  361 1111  953  413
#   TRUE  2091 2304 2329 2388 2419 4600 3974 2581
#  note that excess FF and GG SNPs occur for both NOVEL and not- SNPs.
tmp <- with(data, table(NOVEL, HAP))
tmp[1,]/tmp[2,]
#        AA        BB        CC        DD          EE        FF        GG        HH
# 0.1621234 0.1132812 0.1661657 0.1306533   0.1492352 0.2415217 0.2398088 0.1600155
# but the ratio not-NOVEL/NOVEL is higher for FF and GG
# suggests that some of the FF, GG excess SNPs are really pre-existing SNPs that we did not filter out

#######
# CpG
with(filter(data,SNP==1), table(CPG))
# 1190/(13731+1190) 8% of SNPs are CpG

# relate Novel SNPs to CpG
with(filter(data,SNP==1), table(NOVEL, CPG))
#        CPG
# NOVEL       0     1
#   FALSE  2257   192
#   TRUE  16692  1170
# among Novel SNPs 1170/(16692+1170)  6.5% are CpG
# among non-NOVEL SNPs 192/(2257+192) 7.8% are CpG ??make sense
# odds ratio= 1.67, Recurrent SNPs are slightly more likely to be CpG!

with(data, table(CPG, HAP))
#    HAP
# CPG   AA   BB   CC   DD    EE   FF   GG   HH
#   0 2291 2381 2550 2522  2598 5535 4791 2812
#   1  139  184  166  178   182  176  136  182







